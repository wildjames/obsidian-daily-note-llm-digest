"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => DailyNotesDigestPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/settings.ts
var DEFAULT_SETTINGS = {
  dailyNotesFolder: "daily_notes",
  outputFolder: "daily_digests",
  llmEndpoint: "https://api.openai.com/v1/chat/completions",
  apiKey: "",
  model: "gpt-4o-mini",
  promptTemplate: "Summarize the daily note into concise bullet points and action items.\n\nDate: {{date}}\n\nFocus on key events, decisions, blockers, and next actions.",
  checkIntervalMinutes: 60,
  lastProcessedDate: "",
  lastOpenedDigestDate: ""
};

// src/main.ts
var DailyNotesDigestPlugin = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    __publicField(this, "settings");
  }
  async onload() {
    await this.loadSettings();
    this.addSettingTab(new DailyNotesDigestSettingTab(this.app, this));
    this.addCommand({
      id: "generate-today-digest-now",
      name: "Generate today's digest now",
      callback: async () => {
        await this.processTodayIfNeeded(true);
      }
    });
    await this.processTodayIfNeeded(false);
    this.scheduleDailyCheck();
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  // Heartbeat
  scheduleDailyCheck() {
    const everyMinutes = Math.max(this.settings.checkIntervalMinutes || 60);
    const intervalId = window.setInterval(async () => {
      await this.processTodayIfNeeded(false);
    }, everyMinutes * 60 * 1e3);
    this.registerInterval(intervalId);
  }
  async processTodayIfNeeded(force) {
    const now = /* @__PURE__ */ new Date();
    const today = this.getLocalDateStamp(now);
    const yesterdayDate = new Date(now);
    yesterdayDate.setDate(now.getDate() - 1);
    const yesterday = this.getLocalDateStamp(yesterdayDate);
    await this.processDateIfNeeded(yesterday, force);
    const isAfterCutoff = now.getHours() >= 22;
    if (force || isAfterCutoff) {
      await this.processDateIfNeeded(today, force);
    }
  }
  async processDateIfNeeded(dateStamp, force) {
    const outputPath = this.getSummaryPath(dateStamp);
    if (!force) {
      const summaryExists = await this.app.vault.adapter.exists(outputPath);
      if (summaryExists) {
        return;
      }
    }
    try {
      const dailyNotePath = this.getDailyNotePath(dateStamp);
      const exists = await this.app.vault.adapter.exists(dailyNotePath);
      if (!exists) {
        if (force) {
          new import_obsidian.Notice(`Daily note not found: ${dailyNotePath}`);
        }
        return;
      }
      const noteContents = (await this.app.vault.adapter.read(dailyNotePath)).trim();
      if (!noteContents || noteContents.length < 20) {
        if (force) {
          new import_obsidian.Notice(`Daily note is empty or nearly empty: ${dailyNotePath}`);
        }
        return;
      }
      const messages = this.buildMessages(dateStamp, noteContents);
      const summary = await this.callLlm(messages);
      if (!summary) {
        new import_obsidian.Notice("LLM returned an empty summary");
        return;
      }
      await this.ensureFolderExists(this.settings.outputFolder);
      await this.app.vault.adapter.write(outputPath, summary.trim() + "\n");
      this.settings.lastProcessedDate = dateStamp;
      await this.saveSettings();
      new import_obsidian.Notice(`Daily summary saved: ${outputPath}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error("Failed to generate daily summary", error);
      new import_obsidian.Notice(`Daily summary failed: ${message}`);
    }
  }
  getDailyNotePath(dateStamp) {
    return (0, import_obsidian.normalizePath)(`${this.settings.dailyNotesFolder}/${dateStamp}.md`);
  }
  getSummaryPath(dateStamp) {
    return (0, import_obsidian.normalizePath)(`${this.settings.outputFolder}/${dateStamp}_summary.md`);
  }
  buildMessages(dateStamp, note) {
    const instructionContent = this.settings.promptTemplate.replaceAll("{{date}}", dateStamp);
    return [
      { role: "system", content: instructionContent },
      {
        role: "user",
        content: `Daily note for ${dateStamp}:

${note}`
      }
    ];
  }
  async callLlm(messages) {
    if (!this.settings.llmEndpoint.trim()) {
      throw new Error("LLM endpoint is empty");
    }
    const headers = {
      "Content-Type": "application/json"
    };
    if (this.settings.apiKey.trim()) {
      headers.Authorization = `Bearer ${this.settings.apiKey.trim()}`;
    }
    const response = await (0, import_obsidian.requestUrl)({
      method: "POST",
      url: this.settings.llmEndpoint,
      headers,
      body: JSON.stringify({
        model: this.settings.model,
        messages,
        temperature: 0.2
      })
    });
    if (response.status !== 200) {
      throw new Error(`LLM request failed (${response.status})`);
    }
    const content = response.json?.choices?.[0]?.message?.content;
    if (typeof content !== "string") {
      throw new Error("Unexpected LLM response shape");
    }
    return content;
  }
  async ensureFolderExists(folderPath) {
    const normalized = (0, import_obsidian.normalizePath)(folderPath);
    if (!normalized || normalized === ".") {
      return;
    }
    const exists = await this.app.vault.adapter.exists(normalized);
    if (exists) {
      return;
    }
    const parts = normalized.split("/").filter(Boolean);
    let current = "";
    for (const part of parts) {
      current = current ? `${current}/${part}` : part;
      const segmentExists = await this.app.vault.adapter.exists(current);
      if (!segmentExists) {
        await this.app.vault.createFolder(current);
      }
    }
  }
  getLocalDateStamp(date) {
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, "0");
    const day = `${date.getDate()}`.padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
};
var DailyNotesDigestSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    __publicField(this, "plugin");
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian.Setting(containerEl).setName("Daily notes folder").setDesc("Folder containing daily notes named yyyy-mm-dd.md").addText(
      (text) => text.setPlaceholder("Daily").setValue(this.plugin.settings.dailyNotesFolder).onChange(async (value) => {
        this.plugin.settings.dailyNotesFolder = value.trim() || "Daily";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Summary output folder").setDesc("Folder where yyyy-mm-dd_summary.md files are written").addText(
      (text) => text.setPlaceholder("Daily Summaries").setValue(this.plugin.settings.outputFolder).onChange(async (value) => {
        this.plugin.settings.outputFolder = value.trim() || "Daily Summaries";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("LLM endpoint").setDesc("OpenAI-compatible chat completions endpoint").addText(
      (text) => text.setPlaceholder("https://api.openai.com/v1/chat/completions").setValue(this.plugin.settings.llmEndpoint).onChange(async (value) => {
        this.plugin.settings.llmEndpoint = value.trim();
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("API key").setDesc("Authorization key for your LLM provider").addText(
      (text) => text.setPlaceholder("sk-...").setValue(this.plugin.settings.apiKey).onChange(async (value) => {
        this.plugin.settings.apiKey = value.trim();
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Model").setDesc("Model name sent in the request body").addText(
      (text) => text.setPlaceholder("gpt-4o-mini").setValue(this.plugin.settings.model).onChange(async (value) => {
        this.plugin.settings.model = value.trim() || "gpt-4o-mini";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Summary prompt template").setDesc(
      "Use {{date}}. {{note}} is optional for legacy templates and replaced with guidance because note content is sent separately."
    ).addTextArea(
      (text) => text.setValue(this.plugin.settings.promptTemplate).onChange(async (value) => {
        this.plugin.settings.promptTemplate = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Check interval (minutes)").setDesc("Plugin checks periodically and only processes once per day").addText(
      (text) => text.setPlaceholder("60").setValue(String(this.plugin.settings.checkIntervalMinutes)).onChange(async (value) => {
        const parsed = Number.parseInt(value, 10);
        this.plugin.settings.checkIntervalMinutes = Number.isFinite(parsed) ? Math.max(5, parsed) : 60;
        await this.plugin.saveSettings();
      })
    );
  }
};
