"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => DailyNotesDigestPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/settings.ts
var DEFAULT_SETTINGS = {
  dailyNotesFolder: "Daily",
  outputFolder: "Daily Summaries",
  llmEndpoint: "https://api.openai.com/v1/chat/completions",
  apiKey: "",
  model: "gpt-4o-mini",
  promptTemplate: "Summarize the following daily note into concise bullet points and action items.\n\nDate: {{date}}\n\nDaily note:\n{{note}}",
  checkIntervalMinutes: 60,
  lastProcessedDate: ""
};

// src/main.ts
var DailyNotesDigestPlugin = class extends import_obsidian.Plugin {
  async onload() {
    await this.loadSettings();
    this.addSettingTab(new DailyNotesDigestSettingTab(this.app, this));
    this.addCommand({
      id: "generate-today-digest-now",
      name: "Generate today's digest now",
      callback: async () => {
        await this.processTodayIfNeeded(true);
      }
    });
    await this.processTodayIfNeeded(false);
    this.scheduleDailyCheck();
  }
  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  scheduleDailyCheck() {
    const everyMinutes = Math.max(5, this.settings.checkIntervalMinutes || 60);
    const intervalId = window.setInterval(async () => {
      await this.processTodayIfNeeded(false);
    }, everyMinutes * 60 * 1e3);
    this.registerInterval(intervalId);
  }
  async processTodayIfNeeded(force) {
    const today = this.getLocalDateStamp(/* @__PURE__ */ new Date());
    if (!force && this.settings.lastProcessedDate === today) {
      return;
    }
    try {
      const dailyNotePath = this.getDailyNotePath(today);
      const exists = await this.app.vault.adapter.exists(dailyNotePath);
      if (!exists) {
        if (force) {
          new import_obsidian.Notice(`Daily note not found: ${dailyNotePath}`);
        }
        return;
      }
      const noteContents = await this.app.vault.adapter.read(dailyNotePath);
      const prompt = this.buildPrompt(today, noteContents);
      const summary = await this.callLlm(prompt);
      if (!summary) {
        new import_obsidian.Notice("LLM returned an empty summary");
        return;
      }
      const outputPath = this.getSummaryPath(today);
      await this.ensureFolderExists(this.settings.outputFolder);
      await this.app.vault.adapter.write(outputPath, summary.trim() + "\n");
      this.settings.lastProcessedDate = today;
      await this.saveSettings();
      new import_obsidian.Notice(`Daily summary saved: ${outputPath}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error("Failed to generate daily summary", error);
      new import_obsidian.Notice(`Daily summary failed: ${message}`);
    }
  }
  getDailyNotePath(dateStamp) {
    return (0, import_obsidian.normalizePath)(`${this.settings.dailyNotesFolder}/${dateStamp}.md`);
  }
  getSummaryPath(dateStamp) {
    return (0, import_obsidian.normalizePath)(`${this.settings.outputFolder}/${dateStamp}_summary.md`);
  }
  buildPrompt(dateStamp, note) {
    return this.settings.promptTemplate.split("{{date}}").join(dateStamp).split("{{note}}").join(note);
  }
  async callLlm(prompt) {
    if (!this.settings.llmEndpoint.trim()) {
      throw new Error("LLM endpoint is empty");
    }
    const headers = {
      "Content-Type": "application/json"
    };
    if (this.settings.apiKey.trim()) {
      headers.Authorization = `Bearer ${this.settings.apiKey.trim()}`;
    }
    const response = await (0, import_obsidian.requestUrl)({
      method: "POST",
      url: this.settings.llmEndpoint,
      headers,
      body: JSON.stringify({
        model: this.settings.model,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.2
      })
    });
    if (response.status !== 200) {
      throw new Error(`LLM request failed (${response.status})`);
    }
    const content = response.json?.choices?.[0]?.message?.content;
    if (typeof content !== "string") {
      throw new Error("Unexpected LLM response shape");
    }
    return content;
  }
  async ensureFolderExists(folderPath) {
    const normalized = (0, import_obsidian.normalizePath)(folderPath);
    if (!normalized || normalized === ".") {
      return;
    }
    const exists = await this.app.vault.adapter.exists(normalized);
    if (exists) {
      return;
    }
    const parts = normalized.split("/").filter(Boolean);
    let current = "";
    for (const part of parts) {
      current = current ? `${current}/${part}` : part;
      const segmentExists = await this.app.vault.adapter.exists(current);
      if (!segmentExists) {
        await this.app.vault.createFolder(current);
      }
    }
  }
  getLocalDateStamp(date) {
    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, "0");
    const day = `${date.getDate()}`.padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
};
var DailyNotesDigestSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian.Setting(containerEl).setName("Daily notes folder").setDesc("Folder containing daily notes named yyyy-mm-dd.md").addText(
      (text) => text.setPlaceholder("Daily").setValue(this.plugin.settings.dailyNotesFolder).onChange(async (value) => {
        this.plugin.settings.dailyNotesFolder = value.trim() || "Daily";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Summary output folder").setDesc("Folder where yyyy-mm-dd_summary.md files are written").addText(
      (text) => text.setPlaceholder("Daily Summaries").setValue(this.plugin.settings.outputFolder).onChange(async (value) => {
        this.plugin.settings.outputFolder = value.trim() || "Daily Summaries";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("LLM endpoint").setDesc("OpenAI-compatible chat completions endpoint").addText(
      (text) => text.setPlaceholder("https://api.openai.com/v1/chat/completions").setValue(this.plugin.settings.llmEndpoint).onChange(async (value) => {
        this.plugin.settings.llmEndpoint = value.trim();
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("API key").setDesc("Authorization key for your LLM provider").addText(
      (text) => text.setPlaceholder("sk-...").setValue(this.plugin.settings.apiKey).onChange(async (value) => {
        this.plugin.settings.apiKey = value.trim();
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Model").setDesc("Model name sent in the request body").addText(
      (text) => text.setPlaceholder("gpt-4o-mini").setValue(this.plugin.settings.model).onChange(async (value) => {
        this.plugin.settings.model = value.trim() || "gpt-4o-mini";
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Summary prompt template").setDesc("Use {{date}} and {{note}} placeholders").addTextArea(
      (text) => text.setValue(this.plugin.settings.promptTemplate).onChange(async (value) => {
        this.plugin.settings.promptTemplate = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("Check interval (minutes)").setDesc("Plugin checks periodically and only processes once per day").addText(
      (text) => text.setPlaceholder("60").setValue(String(this.plugin.settings.checkIntervalMinutes)).onChange(async (value) => {
        const parsed = Number.parseInt(value, 10);
        this.plugin.settings.checkIntervalMinutes = Number.isFinite(parsed) ? Math.max(5, parsed) : 60;
        await this.plugin.saveSettings();
      })
    );
  }
};
